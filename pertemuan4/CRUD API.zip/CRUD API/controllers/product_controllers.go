package controllers

import (
	"crud-api/configs"
	"crud-api/models"
	"net/http"
	"strconv"

	"github.com/labstack/echo/v4"
)

// Read All Products
func ReadAllProducts(c echo.Context) (err error) {
	var responses []models.ProductResponse

	// Buat koneksi ke database
	db, err := configs.ConnectDatabase()
	if err != nil {
		return c.JSON(http.StatusInternalServerError, echo.Map{
			"message": "Error connecting to database!",
			"page":    nil,
			"data":    nil,
			"error":   err.Error(),
		})
	}
	defer db.Close()

	const readAllProductsQuery = `
	SELECT
		id, product_name, price, category, description
	FROM
		products
	`

	rows, err := db.QueryContext(c.Request().Context(), readAllProductsQuery)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, echo.Map{
			"message": "Error reading all products!",
			"page":    nil,
			"data":    nil,
			"error":   err.Error(),
		})
	}

	for rows.Next() {
		var response models.ProductResponse

		err = rows.Scan(
			&response.ID,
			&response.ProductName,
			&response.Price,
			&response.Category,
			&response.Description,
		)
		if err != nil {
			return c.JSON(http.StatusInternalServerError, echo.Map{
				"message": "Error reading all products!",
				"page":    nil,
				"data":    nil,
				"error":   err.Error(),
			})
		}

		responses = append(responses, response)
	}

	return c.JSON(http.StatusOK, echo.Map{
		"message": "Success reading all products!",
		"page":    nil,
		"data":    responses,
		"error":   nil,
	})
}

// Read Detail Product
func ReadDetailProducts(c echo.Context) (err error) {
	var response models.ProductResponse

	// Buat koneksi ke database
	db, err := configs.ConnectDatabase()
	if err != nil {
		return c.JSON(http.StatusInternalServerError, echo.Map{
			"message": "Error connecting to database!",
			"page":    nil,
			"data":    nil,
			"error":   err.Error(),
		})
	}
	defer db.Close()

	idParam := c.Param("id")
	id, err := strconv.ParseInt(idParam, 10, 64)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, echo.Map{
			"message": "Error parsing parameter to integer!",
			"page":    nil,
			"data":    nil,
			"error":   err.Error(),
		})
	}

	const readDetailProductQuery = `
	SELECT
		id, product_name, price, category, description
	FROM
		products
	WHERE
		id = ?
	`

	row := db.QueryRowContext(c.Request().Context(), readDetailProductQuery, id)

	err = row.Scan(
		&response.ID,
		&response.ProductName,
		&response.Price,
		&response.Category,
		&response.Description,
	)
	if err != nil {
		return c.JSON(http.StatusInternalServerError, echo.Map{
			"message": "Error reading detail product!",
			"page":    nil,
			"data":    nil,
			"error":   err.Error(),
		})
	}

	return c.JSON(http.StatusOK, echo.Map{
		"message": "Error reading all products!",
		"page":    nil,
		"data":    response,
		"error":   nil,
	})
}

// Create Product

// Update Product

// Delete Product
