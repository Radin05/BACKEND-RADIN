package routes

import (
	"crud-api/controllers"

	"github.com/labstack/echo/v4"
)

func Routes() (e *echo.Echo) {
	e = echo.New()

	productRoutes := e.Group("/product")
	productRoutes.GET("", controllers.ReadAllProducts)

	return
}
